
function pchange() {
    document.getElementById("demo2").innerHTML = "Paragraph changed.";

}
function taylor() {

    document.getElementById("demo3").innerHTML = "Your choice is Taylor";

}

function mitski() {

    document.getElementById("demo3").innerHTML = "Your choice is mitski";

}
